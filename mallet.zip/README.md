
  # Blockchain Wallet App

  This is a code bundle for Blockchain Wallet App. The original project is available at https://www.figma.com/design/r1oYmfyz08wxylahHyD72W/Blockchain-Wallet-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  