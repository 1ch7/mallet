import { Twitter, Facebook, MessageCircle, Instagram, AlertTriangle, Shield, TrendingUp, Calendar, Activity, Wallet } from 'lucide-react';

interface AccountResultsProps {
  walletAddress: string;
}

interface MaliciousAddress {
  address: string;
}

export function AccountResults({ walletAddress }: AccountResultsProps) {
  // Mock data - in a real app, this would be fetched from an API
  const status: 'Unverified' | 'Safe' | 'Suspicious' | 'Malicious' = 'Safe';
  const linkedAccounts = [
    { platform: 'Twitter', username: '@cryptouser123', icon: <Twitter className="w-5 h-5" /> },
    { platform: 'Discord', username: 'cryptouser#1234', icon: <MessageCircle className="w-5 h-5" /> },
    { platform: 'Instagram', username: '@crypto_enthusiast', icon: <Instagram className="w-5 h-5" /> },
  ];
  const balance = '12.5 ETH';
  const daysOld = 1217; // Days since wallet creation
  const lastTransaction = 'May 14, 2026';
  const transactionsLast6Months = 73;

  const maliciousAddresses: MaliciousAddress[] = [
    { address: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb' },
    { address: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063' },
    { address: '0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t' },
  ];

  const statusConfig = {
    Unverified: { color: 'bg-gray-500', textColor: 'text-gray-200', borderColor: 'border-gray-500/30' },
    Safe: { color: 'bg-green-500', textColor: 'text-green-200', borderColor: 'border-green-500/30' },
    Suspicious: { color: 'bg-yellow-500', textColor: 'text-yellow-200', borderColor: 'border-yellow-500/30' },
    Malicious: { color: 'bg-red-500', textColor: 'text-red-200', borderColor: 'border-red-500/30' },
  };

  const currentStatus = statusConfig[status];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden">
      <div className="p-6 space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <p className="text-blue-200 text-sm mb-2">Wallet ID</p>
            <p className="text-white font-mono text-sm break-all">{walletAddress}</p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <p className="text-blue-200 text-sm mb-2">Status</p>
            <div className="flex items-center gap-2">
              <span className={`${currentStatus.color} ${currentStatus.textColor} px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-2`}>
                <Shield className="w-4 h-4" />
                {status}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-black/40 rounded-xl p-4 border border-white/10">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-4 h-4 text-blue-400" />
            <p className="text-blue-200 text-sm">Balance</p>
          </div>
          <p className="text-2xl font-bold text-white">{balance}</p>
        </div>

        <div className="bg-black/40 rounded-xl p-5 border border-white/10">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Linked Accounts</h3>
          </div>
          <div className="space-y-3">
            {linkedAccounts.map((account, index) => (
              <div key={index} className="flex items-center gap-3 bg-white/5 rounded-lg p-3">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center text-blue-400">
                  {account.icon}
                </div>
                <div>
                  <p className="text-white font-medium">{account.platform}</p>
                  <p className="text-blue-200 text-sm">{account.username}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">Days Old</p>
            </div>
            <p className="text-white font-semibold">{daysOld.toLocaleString()} days</p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">Last Transaction</p>
            </div>
            <p className="text-white font-semibold">{lastTransaction}</p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">Transactions Last 6 Months</p>
            </div>
            <p className="text-white font-semibold">{transactionsLast6Months}</p>
          </div>
        </div>

        {maliciousAddresses.length > 0 && (
          <div className="bg-red-500/10 rounded-xl p-5 border border-red-500/30">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <h3 className="text-lg font-semibold text-white">Flagged Malicious Addresses ({maliciousAddresses.length})</h3>
            </div>
            <div className="space-y-2">
              {maliciousAddresses.map((addr, index) => (
                <div key={index} className="bg-black/40 rounded-lg p-3 border border-red-500/20">
                  <div className="flex items-center justify-between">
                    <p className="text-white font-mono text-sm break-all flex-1">{addr.address}</p>
                    <span className="bg-red-500 text-white px-2 py-1 rounded text-xs font-semibold ml-3 whitespace-nowrap">
                      Malicious
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
